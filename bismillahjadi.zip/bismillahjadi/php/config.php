<?php 
 
 $con = mysqli_connect("localhost","root","","foundationforge", 8111) or die("Couldn't connect");

?>
